package io.nuls.contract.token;

import io.nuls.contract.sdk.Address;
import io.nuls.contract.sdk.Block;
import io.nuls.contract.sdk.Event;
import io.nuls.contract.sdk.annotation.Required;

import java.util.*;

import java.math.BigInteger;

import static io.nuls.contract.sdk.Utils.require;


public interface HenaFunc {


    public boolean transferOwner(@Required Address from, @Required Address to, @Required BigInteger value);

    class LockUserInfo{
        boolean totalLocked = false;
        String tag = "";
    }
    
    class TimeLock {

        long startTime;
        long endTime;
        long lockedTime;
        BigInteger lockedBalance;

        public TimeLock(long startTime, long endTime, BigInteger lockedBalance ){

            this.startTime = startTime;
            this.endTime = endTime;
            this.lockedBalance = lockedBalance;
        }

        public boolean equal( TimeLock lock){

            if( this.endTime != lock.endTime)
                return false;
            return true;
        }

    }

    

    class LockMgr {

        int standardBalance;
        Map<Address, List<TimeLock>> Locks = new HashMap<Address, List<TimeLock>>();
        Map<Address, LockUserInfo> lockUserInfos = new HashMap<Address, LockUserInfo>();
        HenaToken token;
        Address owner;
        Address manager;

        public LockMgr(Address owner, Address manager, HenaToken token){
            this.token = token;
            this.owner = owner;
            this.manager = manager;
        }

        void requireOwner(Address address) {
            require(owner.equals(address), "Only owners are allowed");
        }

        void requireManager(Address address) {
            require( address == owner || address == manager, "Only owners or manager are allowed");
        }

        public boolean lock(@Required Address targetAddress){
            LockUserInfo userInfo = lockUserInfos.get(targetAddress);
            if( userInfo == null){
                userInfo = new LockUserInfo();
                lockUserInfos.put(targetAddress, userInfo);
            }
            userInfo.totalLocked = true;
            return true;
        }

        public boolean unlock(@Required Address targetAddress){
            LockUserInfo userInfo = lockUserInfos.get(targetAddress);
            if( userInfo == null){
                return false;
            }
            userInfo.totalLocked = false;
            return true;
        }

         public boolean addLock(@Required Address targetAddress,@Required long startTime,@Required long endTime,@Required int persentage){

             if( persentage < 0 || persentage > 100)
                 return false;
             long currentTime = getTime();
             if( currentTime > endTime)
                 return false;

             List<TimeLock> lockList = Locks.get(targetAddress);
             if (lockList == null) {
                 lockList = new ArrayList<TimeLock>();
             }

             BigInteger lockBalance = token.balanceOf(targetAddress).multiply(BigInteger.valueOf(100)).divide(BigInteger.valueOf(persentage));
             lockList.add(new TimeLock( startTime, endTime, lockBalance));

             return true;
         }

        public boolean removeLock(@Required Address targetAddress, @Required int endTime){

             List<TimeLock> lockList = Locks.get(targetAddress);

             if (lockList == null) {
               return false;
            }

            TimeLock lock = new TimeLock(0, endTime, BigInteger.valueOf(0));
            for(Iterator<TimeLock> it = lockList.iterator(); it.hasNext() ; )
            {
                TimeLock value = it.next();
                if(value.equal(lock))
                {
                    it.remove();
                }
            }
            return true;
        }

        public BigInteger getLockBalance(@Required Address targetAddress){

            LockUserInfo userInfo = lockUserInfos.get(targetAddress);
            if(userInfo != null){
                if( userInfo.totalLocked == true){
                    return token.balanceOf(targetAddress);
                }
            }

            BigInteger lockedBalance = BigInteger.ZERO;

            List<TimeLock> lockList = Locks.get(targetAddress);
            if (lockList == null) {
                return lockedBalance;
            }
            long currentTime = getTime();
            for (TimeLock lock : lockList) {

                if( currentTime >= lock.startTime && currentTime <= lock.endTime){
                    lockedBalance = lockedBalance.add(lock.lockedBalance);
                }
            }
            return lockedBalance;
        }

        long getTime(){

            return Block.timestamp();
            //return System.currentTimeMillis() / 1000L;
        }
    }

}
